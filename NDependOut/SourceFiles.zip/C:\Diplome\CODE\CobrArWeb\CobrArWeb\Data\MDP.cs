﻿namespace CobrArWeb.Data
{
    public class MDP
    {
    public int Id { get; set; }
        public string Nom { get; set; }
    }
}
