﻿using CobrArWeb.Data;
using CobrArWeb.Models.RechercheArbo;

public class CategoryViewModel
{
    public string Categorie { get; set; }


    public List<SousCategorieViewModel> SousCategorie { get; set; }
    
}
