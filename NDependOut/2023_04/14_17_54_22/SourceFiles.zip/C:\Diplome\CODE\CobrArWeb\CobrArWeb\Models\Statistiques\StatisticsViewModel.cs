﻿using CobrArWeb.Data;

namespace CobrArWeb.Models.Statistiques
{
    public class StatisticsViewModel
    {
        public List<ProductHistory> ProductHistoryList { get; set; }
        public StatistiquesVentesModel StatistiquesVentes { get; set; }
    }
}