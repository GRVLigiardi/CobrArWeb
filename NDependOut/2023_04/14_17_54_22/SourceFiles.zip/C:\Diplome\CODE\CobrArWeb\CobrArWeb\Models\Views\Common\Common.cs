﻿namespace CobrArWeb.Models.Views.Common
{
    public class ErrorVM
    {
        public string ErrorTag { get; set; }
        public string ErrorText { get; set; }
    }
}