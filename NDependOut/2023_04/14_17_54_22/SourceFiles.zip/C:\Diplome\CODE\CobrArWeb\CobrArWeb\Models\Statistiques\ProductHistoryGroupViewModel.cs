﻿namespace CobrArWeb.Models.Statistiques
{
    public class ProductHistoryGroupViewModel
    {
        public int ProductId { get; set; }
        public List<ProductHistoryViewModel> Histories { get; set; }
    }
}
