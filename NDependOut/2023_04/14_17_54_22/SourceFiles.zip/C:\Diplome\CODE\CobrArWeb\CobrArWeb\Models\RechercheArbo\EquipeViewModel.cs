﻿using CobrArWeb.Models.RechercheArbo;

namespace CobrArWeb.Models.RechercheArbo
{
    public class EquipeViewModel
    {
        public string Equipe { get; set; }

        public List<CategoryViewModel> Categorie { get; set; }

      }
}